# How to Include one HTML file into Another Without any Framework or Library
This projects shows how to include one HTML file into another without and library or framework in order to avoid code repitition.
It also shows how to make js file stiched in from another file into HTML file make work.
